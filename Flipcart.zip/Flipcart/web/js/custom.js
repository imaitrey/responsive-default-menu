// require([ 'jquery', 'jquery/ui'], function($){
//     jQuery(document).ready(function() {    
//       jQuery('li.level1').addClass('expand');
//       jQuery('li.level0 a').after('<div class="mydiv">');
//       jQuery('.mydiv').click(function(event) {
//               event.preventDefault();
//               alert("prevent");
//               var data = jQuery(this).next().find('.level1');
//               console.log(data);
//       });    
//     });
// });

require(['jquery', 'jquery/ui'], function($){
  $(document).ready(function() {
    $('li.level0 li.parent > a').append('<span class="rm-expand"></span>');
    $('.rm-expand').click(function() {
      if ($(this).hasClass('open')) {
        $(this).parent().parent().find('ul:first').slideUp();
        $(this).removeClass('open');
      } else {
        $(this).parent().parent().find('ul:first').slideDown();
        $(this).addClass('open');
      }
      return false;
    });
  });
});

